/*
 * File:   main.c
 * Author: ABHISHAKE
 *
 * Created on 2 July, 2026, 12:21 AM
 */



#include <xc.h>
#include "adc.h"
#include "can.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "main.h"

void delay(unsigned short factor)
{
unsigned short i, j;

for (i = 0; i < factor; i++)
{
for (j = 500; j--; );
}
}

void init_config()
{
    TRISB = 0x00;
    PORTB = 0x00;
    init_adc();
    init_can();
    init_matrix_keypad();
}

void main(void)
{
    init_config();
    unsigned char str[5];
    unsigned char gear[] = {'N','1','2','3','4','5','R'};
    unsigned int speed = 0;
    unsigned int i=0;
    
    while(1)
    {
        unsigned char key = read_switches(STATE_CHANGE);
        if(key == MK_SW1 && i<6)
        {
            i++;
        }
        else if(key == MK_SW2 && i>0)
        {
            i--;
        }
       
        if(gear[i] == 'N')
        {
            speed=0;
        }
        else if(gear[i] == 'R')
        {
            speed = 10;
        }
        else
        {
            unsigned short adc_value = read_adc(CHANNEL4);
            speed = adc_value / 10.23;
        }

        while(TXB0REQ);
       
        str[0] = (speed / 100) + '0';
        str[1] = ((speed / 10) % 10) + '0';
        str[2] = (speed % 10) + '0';
        str[3] = gear[i];
        str[4] = '\0';

        can_transmit(str,GEAR_IDH, GEAR_IDL);
}
}