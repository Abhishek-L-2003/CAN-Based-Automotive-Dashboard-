#ifndef MAIN_H
#define MAIN_H

#include <xc.h>

#define _XTAL_FREQ 20000000

//#define SPEED_IDH      0x00
//#define SPEED_IDL      0x00

#define GEAR_IDH       0x30
#define GEAR_IDL       0x00

/* Defines the data */
#define TRUE			1
#define FALSE			0

#endif