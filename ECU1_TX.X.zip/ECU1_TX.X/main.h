#ifndef MAIN_H
#define MAIN_H

#include <xc.h>

#define _XTAL_FREQ 20000000

#define ADC_IDH       0x10
#define ADC_IDL       0x00

#define INDICATOR_IDH 0x6B
#define INDICATOR_IDL 0x00

/* Defines the data */
#define TRUE			1
#define FALSE			0

#endif