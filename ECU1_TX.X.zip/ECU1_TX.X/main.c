/*
 * File:   main.c
 * Author: ABHISHAKE
 *
 * Created on 2 July, 2026, 12:10 AM
 */

#include <xc.h>
#include "can.h"
#include "adc.h"
#include "main.h"
#include "matrix_keypad.h"


void init_config(void)
{

	init_can();
    
    init_adc();
    
    init_matrix_keypad();
}

void main(void) {
    
    unsigned char str[5],rpm[5];
    unsigned char rx_data[6];
    unsigned char key,data;
    init_config();

    while(1)
    {
        
    unsigned short adc_value = (read_adc(CHANNEL4)/10.23)*60;
    
    rpm[0]=(adc_value / 1000)+'0';
    rpm[1]=((adc_value / 100)%10)+'0';
    rpm[2]=(adc_value / 10)%10+'0';
    rpm[3]=(adc_value % 10)+'0';
    rpm[4]='\0';
    
    can_transmit(rpm,ADC_IDH,ADC_IDL);
    __delay_ms(10);
    
    key = read_switches(1);
 
	if (key == MK_SW1)
	{
        str[0]='<';
        str[1]='-';
        str[2]=' ';
        str[3]='1';
	}
    else if(key == MK_SW2)
    {
        str[0]=' ';
        str[1]='-';
        str[2]='>';
        str[3]='2';
    }
    else if(key == MK_SW3)
    {
        str[0]='<';
        str[1]='-';
        str[2]='>';
        str[3]='3';
    }
    else if(key == MK_SW4)
    {
        str[0]='O';
        str[1]='F';
        str[2]='F';
        str[3]='4';
    }
    can_transmit(str,INDICATOR_IDH,INDICATOR_IDL);   
    __delay_ms(10);
    }
}

