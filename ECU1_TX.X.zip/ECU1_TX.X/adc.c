/*
 * File:   adc.c
 * Author: ABHISHAKE
 *
 * Created on 4 June, 2026, 4:11 PM
 */


#include <xc.h>
#include "adc.h"

void init_adc(void)
{
    ADON=0; // disable the ADC for configuration
    
//    PCFG0=0; // select all the GPIO pin as analog input
//    PCFG1=0;
//    PCFG2=0;
//    PCFG3=0;
    
    VCFG0=0;
    VCFG1=0; // to select as default(Vref)
    
    ADCS0=0; // for clock/frequency select
    ADCS1=1;
    ADCS2=0;
    
    ACQT0=0; // acquisition time(6.4ms)
    ACQT1=1;
    ACQT2=0;
    
    ADFM=1; // right justification
    
    ADON=1; // enable the ADC
    
}


unsigned short read_adc(unsigned char channel)
{
    ADCON0= (ADCON0 & 0XC3) | (channel<<2);
    
    GO=1; // start conversion
    
    while(GO); // wait tell until 0
    
    return (ADRESH<<8) | (ADRESL);
}
