/*
 * File:   can.c
 * Author: ABHISHAKE
 *
 * Created on 29 June, 2026, 10:00 PM
 */


#include <xc.h>
#include "can.h"
#include "main.h"

/* Global Variables */
unsigned char can_payload[13];

typedef enum _CanOpMode
{
	e_can_op_mode_bits    = 0xE0,			/* Use this to access opmode bits */
	e_can_op_mode_normal  = 0x00,
	e_can_op_mode_sleep   = 0x20,
	e_can_op_mode_loop    = 0x40,
	e_can_op_mode_listen  = 0x60,
	e_can_op_mode_config  = 0x80
} CanOpMode;

/* Configure the CAN Module */
void init_can(void)
{
	/* CAN_TX = RB2, CAN_RX = RB3 */
	TRISB2 = 0;								/* CAN TX */
	TRISB3 = 1;								/* CAN RX */

	/* Enter CAN module into config mode */
							 /* clear previous mode */
	  CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_config);                     	/* set new mode */

	/* Wait untill desired mode is set */
	while (CANSTAT != 0x80);

	/* Enter CAN module into Mode 0 */
	ECANCON = 0x00;

	/* Initialize CAN Timing 8MHz */
	BRGCON1 = 0xE1;							/* 1110 0001, SJW=4, TQ, BRP 4 */
	BRGCON2 = 0x1B;							/* 0001 1011, SEG2PHTS 1 sampled once PS1=4TQ PropagationT 4TQ */
	BRGCON3 = 0x03;							/* 0000 0011, PS2, 4TQ */

	/*
	 * Enable Filters
	 * Filter 0
	 */
	/* Enable Filter 0 and Filter 1 */
    RXFCON0 = 0x03;

    /* Receive Mask 0
    * Compare all Standard ID bits
    */
//    RXM0SIDH = 0xFF;
//    RXM0SIDL = 0xE0;

    /* Filter 0 : Indicator Message (6B 80) */
    RXF0SIDH = ADC_IDH;
    RXF0SIDL = ADC_IDL;

    /* Filter 1 : ADC Message (C0 55) */
    RXF1SIDH = INDICATOR_IDH;
    RXF1SIDL = INDICATOR_IDL;

	/* Enter CAN module into Normal mode */
	CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_normal);

	/* Set Receive Mode for buffers */
	RXB0CON = 0x00;
}

/* Transmit Sample Message */
void can_transmit(unsigned char data[],unsigned char msg_idh,unsigned char msg_idl)
{

	/* 0x35E  0110 1011 110 */
	TXB0SIDH = msg_idh;		/* Standard Identifier */
	TXB0SIDL = msg_idl;		/* Standard Identifier */

	TXB0DLC = 0X05;			/* Data Length Count */
	TXB0D0 = data[0];			/* DataByte 0 */
	TXB0D1 = data[1];			/* DataByte 1 */
	TXB0D2 = data[2];			/* DataByte 2 */
	TXB0D3 = data[3];			/* DataByte 3 */
	TXB0D4 = data[4];			/* DataByte 4 */
//	TXB0D5 = 0;			/* DataByte 5 */
//	TXB0D6 = 0;			/* DataByte 6 */
//	TXB0D7 = 0;			/* DataByte 7 */

	TXB0REQ = 1;			/* Set the buffer to transmit */
    
}
