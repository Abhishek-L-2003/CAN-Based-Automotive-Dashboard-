/*
 * File:   can.c
 * Author: ABHISHAKE
 *
 * Created on 29 June, 2026, 10:00 PM
 */


#include <xc.h>
#include "can.h"
#include "main.h"
#include "clcd.h"

/* Global Variables */
unsigned char can_payload[13];

typedef enum _CanOpMode
{
	e_can_op_mode_bits    = 0xE0,			/* Use this to access opmode bits */
	e_can_op_mode_normal  = 0x00,
	e_can_op_mode_sleep   = 0x20,
	e_can_op_mode_loop    = 0x40,
	e_can_op_mode_listen  = 0x60,
	e_can_op_mode_config  = 0x80
} CanOpMode;

/* Configure the CAN Module */
void init_can(void)
{
	/* CAN_TX = RB2, CAN_RX = RB3 */
	TRISB2 = 0;								/* CAN TX */
	TRISB3 = 1;								/* CAN RX */

	/* Enter CAN module into config mode */
							 /* clear previous mode */
	  CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_config);                     	/* set new mode */

	/* Wait untill desired mode is set */
	while (CANSTAT != 0x80);

	/* Enter CAN module into Mode 0 */
	ECANCON = 0x00;

	/* Initialize CAN Timing 8MHz */
	BRGCON1 = 0xE1;							/* 1110 0001, SJW=4, TQ, BRP 4 */
	BRGCON2 = 0x1B;							/* 0001 1011, SEG2PHTS 1 sampled once PS1=4TQ PropagationT 4TQ */
	BRGCON3 = 0x03;							/* 0000 0011, PS2, 4TQ */

	/*
	 * Enable Filters
	 * Filter 0
	 */
	/* Enable Filter 0 and Filter 1 */
    RXFCON0 = 0x03;

    /* Receive Mask 0
    * Compare all Standard ID bits
    */
//    RXM0SIDH = 0xFF;
//    RXM0SIDL = 0xE0;

    /* Filter 0 : ADC Message (6B 80) */
    RXF0SIDH = ADC_IDH;
    RXF0SIDL = ADC_IDL;

    /* Filter 1 : INDICATOR Message (C0 55) */
    RXF1SIDH = INDICATOR_IDH;
    RXF1SIDL = INDICATOR_IDL;
    
    /* Filter 2 : Speed Message (C0 55) */
//    RXF2SIDH = SPEED_IDH;
//    RXF2SIDL = SPEED_IDL;
    
    /* Filter 3 : Gear Message (C0 55) */
    RXF2SIDH = GEAR_IDH;
    RXF2SIDL = GEAR_IDL;
    
	/* Enter CAN module into Normal mode */
	CAN_SET_OPERATION_MODE_NO_WAIT(e_can_op_mode_normal);

	/* Set Receive Mode for buffers */
	RXB0CON = 0x00;
}

/* Check the buffers, if it have message */
unsigned char can_receive(void)
{
	unsigned char rx_msg_flag = 0;

	if (RXB0FUL) /* CheckRXB0 */
	{
		can_payload[SIDH] = RXB0SIDH;
		can_payload[SIDL] = RXB0SIDL;
		can_payload[DLC] = RXB0DLC;
		can_payload[D0] = RXB0D0;
		can_payload[D1] = RXB0D1;
		can_payload[D2] = RXB0D2;
		can_payload[D3] = RXB0D3;
		can_payload[D4] = RXB0D4;
//		can_payload[D5] = RXB0D5;
//		can_payload[D6] = RXB0D6;
//		can_payload[D7] = RXB0D7;

		RXB0FUL = 0;
		RXB0IF = 0;

		return TRUE;
	}
	else
	{
		return FALSE;
	}    
}