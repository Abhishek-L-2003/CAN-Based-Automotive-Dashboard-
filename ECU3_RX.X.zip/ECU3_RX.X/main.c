/*
 * File:   main.c
 * Author: ABHISHEK L
 *
 * Created on 2 July, 2026, 12:31 AM
 
 * description : CAN based automotive dashboard

Developed a Vehicle Dashboard System using the PIC18F4580 microcontroller.

Implemented CAN (Controller Area Network) protocol for communication between multiple ECUs.

Read speed using the ADC and transmitted it over the CAN bus.

Controlled gear selection and indicator status using keypad inputs.

Assigned unique CAN message IDs for speed, gear, RPM, and indicator data.

Displayed real-time Gear, Speed, RPM, and Indicator status on a 16�2 CLCD.

Controlled external LEDs to indicate Left, Right, and Hazard signals.

Used CAN transmit and receive functions for reliable real-time data exchange.

Designed the system using Embedded C in MPLAB X IDE with the XC8 compiler.

Demonstrated a basic automotive dashboard architecture based on distributed ECUs communicating over the CAN network.
 */


#include <xc.h>
#include "can.h"
#include "clcd.h"
#include "main.h"

unsigned char indicator_state='4';
void init_config(void)
{
    init_can();
	init_clcd();
}

void main(void) {
    
    unsigned char rx_data[6];
    init_config();
    TRISB=0X08;
    PORTB=0X00;
    
    while(1)
    {
    if(can_receive())
        {
        if(can_payload[SIDH]==ADC_IDH  && can_payload[SIDL]==ADC_IDL)
            {
            
                clcd_print("RPM ",LINE1(4));
                clcd_print(&can_payload[D0],LINE2(4));
            }
        else if(can_payload[SIDH]==INDICATOR_IDH && can_payload[SIDL]==INDICATOR_IDL)
            {
                rx_data[0] = can_payload[D0];
                rx_data[1] = can_payload[D1];
                rx_data[2] = can_payload[D2];
                rx_data[3] = can_payload[D3];
                rx_data[4] = '\0';
           
                clcd_print("IND",LINE1(13));
                clcd_print(rx_data,LINE2(13));
                
                indicator_state = rx_data[3];
                static unsigned int delay = 0;

    delay++;

    if (delay > 10)
    {
        delay = 0;
    }

     if (delay <= 5)      // ON period
    {
        if (indicator_state == '1')
        {
            PORTBbits.RB0=1;
            PORTBbits.RB1=1;
        }
        else if (indicator_state == '2')
        {
            PORTBbits.RB6=1;
            PORTBbits.RB7=1;
            
        }
        else if (indicator_state == '3')
        {
            PORTBbits.RB0=1;
            PORTBbits.RB1=1;
            PORTBbits.RB6=1;
            PORTBbits.RB7=1;
        }
        else if (indicator_state == '4')
        {
            PORTBbits.RB0=0;
            PORTBbits.RB1=0;
            PORTBbits.RB7=0;
            PORTBbits.RB6=0;
        }
    }
     else   
    {
        PORTBbits.RB0=0;
        PORTBbits.RB1=0;
        PORTBbits.RB6=0;
        PORTBbits.RB7=0;
    }
        }
        else if(can_payload[SIDH]==GEAR_IDH && can_payload[SIDL]==GEAR_IDL)
            {
            unsigned char speed[4];
               
            speed[0] = can_payload[D0];
            speed[1] = can_payload[D1];
            speed[2] = can_payload[D2];
            speed[3] = '\0';
            
            clcd_print("SPD ",LINE1(0));
            clcd_print(speed,LINE2(0));
            
                rx_data[0] = can_payload[D3];
                rx_data[1] = '\0';

                clcd_print("GR ",LINE1(9));
                clcd_print(rx_data,LINE2(9));
            }
        }
    }
}
